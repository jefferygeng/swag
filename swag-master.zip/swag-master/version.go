package swag

// Version of swag.
const Version = "v1.7.7"
