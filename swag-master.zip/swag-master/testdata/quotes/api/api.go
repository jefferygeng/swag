package api

// RandomFunc dogoc
// @Description.markdown api
// @Router /random [get]
func RandomFunc() {}
