# General API documentation

**Warning** this api is not production ready. Use at your own risk.

In order to re-generate the documentation you need to run

`swago init --md .`