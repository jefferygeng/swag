# Admin TAG API documentation

**Admin** functions goes here 

For more info please read [link](/docs/readme.md).

